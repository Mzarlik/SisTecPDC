window.sr = ScrollReveal()
    sr.reveal('.portafolio',{
        duration: 3000,
        origin: 'bottom',
        distance: '-100px'
    })
    sr.reveal('.about-services',{
        duration: 3000,
        origin: 'left',
        distance: '-100px'
    })